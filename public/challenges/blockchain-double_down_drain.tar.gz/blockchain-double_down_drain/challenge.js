const { ethers } = require("ethers");

// Recon helper for Double Down Drain. It does NOT solve the challenge -- it
// connects to your deployed instance and prints the state worth looking at.
//
//   RPC_URL        (default http://127.0.0.1:8545)
//   PRIVATE_KEY    your funded key
//   VAULT_ADDRESS  the DoubleDownVault (read it off Setup.vault())

const RPC_URL = process.env.RPC_URL || "http://127.0.0.1:8545";
const PRIVATE_KEY = process.env.PRIVATE_KEY;
const VAULT_ADDRESS = process.env.VAULT_ADDRESS;

const ABI = [
  "function owner() view returns (address)",
  "function skim()",
  "function flashLoan(address module, bytes data)",
];

async function main() {
  if (!PRIVATE_KEY || !VAULT_ADDRESS) {
    throw new Error("Set PRIVATE_KEY and VAULT_ADDRESS first");
  }

  const provider = new ethers.JsonRpcProvider(RPC_URL);
  const wallet = new ethers.Wallet(PRIVATE_KEY, provider);
  const vault = new ethers.Contract(VAULT_ADDRESS, ABI, wallet);

  console.log("Connected wallet:", wallet.address);
  console.log("Vault address:  ", VAULT_ADDRESS);
  console.log("Vault balance:  ", (await provider.getBalance(VAULT_ADDRESS)).toString());
  console.log("Vault owner:    ", await vault.owner());

  console.log("\nflashLoan(module, data) runs YOUR module via delegatecall while the");
  console.log("session is open. skim() pays the *owner* and needs an open session.");
  console.log("Neither trick is enough alone -- you need both, in one transaction.");
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
