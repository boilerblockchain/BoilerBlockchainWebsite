# Double Down Drain

The casino's high-roller vault doubled down: it merged both house gadgets into
one contract — a flash loan that runs your module via `delegatecall`, and a
`skim()` that only works while a session is live.

Your task is to drain the vault. Neither trick is enough on its own.

## Files

- `contracts/DoubleDownVault.sol` - the high-roller vault (your target)
- `contracts/Setup.sol` - setup wrapper; deploy with `10 ether`, then use `Setup.vault()`
- `challenge.js` - helper for inspecting a deployed vault

## Hint

`flashLoan(module, data)` opens a transient session and `delegatecall`s your
module in the vault's storage. `skim()` pays the **owner**. You aren't the owner
— yet. Do everything in one transaction.

## Run locally

The handout includes the same baked-state Anvil image used by the remote
instance, configured with a dummy local flag:

```bash
docker compose up --build
```

Once it reports ready, open another terminal:

```bash
curl http://127.0.0.1:8545/
```

The response contains the funded player key and contract addresses. Use
`http://127.0.0.1:8545/` as the RPC URL. The local `/claim` response returns
`fake{flag}` after the challenge is solved.
