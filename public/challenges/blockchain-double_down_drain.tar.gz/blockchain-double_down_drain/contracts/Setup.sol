// SPDX-License-Identifier: MIT
pragma solidity ^0.8.28;

import {DoubleDownVault} from "./DoubleDownVault.sol";

/// @title Setup - deploys and seeds the challenge instance.
/// @notice Deploy with 10 ETH. Drain the vault to win.
contract Setup {
    DoubleDownVault public vault;

    constructor() payable {
        require(msg.value == 10 ether, "fund Setup with 10 ETH");
        vault = new DoubleDownVault{value: 10 ether}();
    }

    function isSolved() external view returns (bool) {
        return address(vault).balance == 0;
    }
}
