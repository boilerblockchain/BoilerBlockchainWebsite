// SPDX-License-Identifier: MIT
pragma solidity ^0.8.28; // transient storage -> solc >= 0.8.28, evm >= cancun

/// @title DoubleDownVault - the casino's high-roller vault.
/// @notice The house merged its two flagship gadgets into one contract:
///         * an "upgradeable" flash loan that runs a borrower module via
///           `delegatecall` (so the module executes in THIS vault's storage), and
///         * a transient `inSession` flag (EIP-1153) that guards `skim()`.
/// @dev    Two house assumptions, both false: modules are "trusted", and
///         `skim()` is "only reachable by the house, mid-flash".
contract DoubleDownVault {
    address public owner; // slot 0
    bool transient inSession; // transient session flag (auto-clears each tx)

    constructor() payable {
        owner = msg.sender;
    }

    /// @notice Open a flash session and hand control to a borrower module.
    /// @dev    delegatecall => the module's code runs against the vault's
    ///         storage. `inSession` stays true for the rest of this transaction.
    function flashLoan(address module, bytes calldata data) external {
        inSession = true;
        (bool ok,) = module.delegatecall(data);
        require(ok, "module failed");
    }

    /// @notice Skim the whole balance to the owner. Meant for the house to
    ///         rebalance mid-flash -- hence the `inSession` guard.
    function skim() external {
        require(inSession, "no active session");
        (bool ok,) = payable(owner).call{value: address(this).balance}("");
        require(ok, "transfer failed");
    }

    receive() external payable {}
}
