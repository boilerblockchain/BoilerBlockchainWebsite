#!/usr/bin/env python3
"""Start the baked Anvil chain and expose a filtered HTTP JSON-RPC endpoint."""

from __future__ import annotations

import atexit
import json
import os
import re
import signal
import subprocess
import threading
import time
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any
from urllib.parse import urlsplit

ANVIL_URL = "http://127.0.0.1:8546"
CHAIN_ID = 31337
MAX_BODY = 2 * 1024 * 1024
MAX_BATCH_SIZE = 100

PLAYER_PRIVATE_KEY = (
    "0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80"
)
PLAYER_ADDRESS = "0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266"
SETUP_ADDRESS = "0x5FbDB2315678afecb367f032d93F642f64180aa3"

# Mirror paradigmctf.py's Anvil proxy policy: permit ordinary client RPC while
# blocking node/admin namespaces and every unlocked-account signing method.
ALLOWED_NAMESPACES = {"web3", "eth", "net"}
DISALLOWED_METHODS = {
    "eth_sign",
    "eth_signTransaction",
    "eth_signTypedData",
    "eth_signTypedData_v1",
    "eth_signTypedData_v3",
    "eth_signTypedData_v4",
    "eth_sendTransaction",
    "eth_sendTransactionSync",
    "eth_sendUnsignedTransaction",
}


class StartupError(RuntimeError):
    pass


def rpc_error(request_id: object, code: int, message: str) -> dict[str, Any]:
    return {
        "jsonrpc": "2.0",
        "id": request_id,
        "error": {"code": code, "message": message},
    }


def validate_request(request: object) -> dict[str, Any] | None:
    if not isinstance(request, dict):
        return rpc_error(None, -32600, "expected JSON object")

    request_id = request.get("id")
    method = request.get("method")
    if request_id is None:
        return rpc_error(None, -32600, "invalid JSON-RPC id")
    if not isinstance(method, str):
        return rpc_error(request_id, -32600, "invalid JSON-RPC method")

    namespace = method.split("_", 1)[0]
    if namespace not in ALLOWED_NAMESPACES or method in DISALLOWED_METHODS:
        return rpc_error(request_id, -32600, "forbidden JSON-RPC method")
    return None


def forward(payload: object) -> object:
    request = urllib.request.Request(
        ANVIL_URL,
        data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=20) as response:
            return json.loads(response.read())
    except (
        OSError,
        TimeoutError,
        urllib.error.URLError,
        json.JSONDecodeError,
    ):
        return rpc_error(None, -32602, "failed to reach Anvil")


def proxy(payload: object) -> object:
    if not isinstance(payload, list):
        error = validate_request(payload)
        return error if error is not None else forward(payload)

    if not payload or len(payload) > MAX_BATCH_SIZE:
        return rpc_error(
            None, -32600, f"invalid batch (maximum {MAX_BATCH_SIZE} requests)"
        )

    errors: list[object] = []
    valid: list[object] = []
    for item in payload:
        error = validate_request(item)
        if error is None:
            valid.append(item)
        else:
            errors.append(error)

    if not valid:
        return errors
    upstream = forward(valid)
    responses = upstream if isinstance(upstream, list) else [upstream]
    return errors + responses


def rpc(method: str, params: list[object]) -> object:
    result = forward(
        {"jsonrpc": "2.0", "id": 1, "method": method, "params": params}
    )
    if not isinstance(result, dict) or "error" in result or "result" not in result:
        raise StartupError(f"Anvil call failed: {method}")
    return result["result"]


def wait_for_anvil(process: subprocess.Popen[bytes]) -> None:
    deadline = time.monotonic() + 20
    while time.monotonic() < deadline:
        if process.poll() is not None:
            raise StartupError("Anvil exited during startup")
        try:
            if rpc("eth_chainId", []) == hex(CHAIN_ID):
                return
        except StartupError:
            pass
        time.sleep(0.1)
    raise StartupError("Anvil did not become ready")


def read_vault_address() -> str:
    encoded = rpc(
        "eth_call",
        [{"to": SETUP_ADDRESS, "data": "0xfbfa77cf"}, "latest"],
    )
    if not isinstance(encoded, str) or not re.fullmatch(
        r"0x[0-9a-fA-F]{64}", encoded
    ):
        raise StartupError("Setup returned an invalid vault address")
    return f"0x{encoded[-40:]}"


def is_solved() -> bool:
    encoded = rpc(
        "eth_call",
        [{"to": SETUP_ADDRESS, "data": "0x64d98f6e"}, "latest"],
    )
    return isinstance(encoded, str) and int(encoded, 16) == 1


def request_origin(handler: BaseHTTPRequestHandler) -> str:
    host = handler.headers.get("Host", "")
    if not re.fullmatch(r"[A-Za-z0-9.-]+(?::[0-9]{1,5})?", host):
        return ""
    forwarded = handler.headers.get("X-Forwarded-Proto", "").split(",", 1)[0]
    scheme = forwarded.strip() if forwarded.strip() in {"http", "https"} else "http"
    return f"{scheme}://{host}"


class Server(ThreadingHTTPServer):
    daemon_threads = True
    request_queue_size = 64


class Handler(BaseHTTPRequestHandler):
    server_version = "DoubleDownDrain/1.0"
    protocol_version = "HTTP/1.1"

    def cors(self) -> None:
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "content-type")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")

    def send_json(self, value: object, status: int = 200) -> None:
        body = json.dumps(value, separators=(",", ":")).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.cors()
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self) -> None:  # noqa: N802
        self.send_response(204)
        self.send_header("Content-Length", "0")
        self.cors()
        self.end_headers()

    def do_GET(self) -> None:  # noqa: N802
        path = urlsplit(self.path).path
        if path == "/health":
            try:
                healthy = rpc("eth_chainId", []) == hex(CHAIN_ID)
            except StartupError:
                healthy = False
            self.send_json({"ok": healthy}, 200 if healthy else 503)
            return
        if path == "/claim":
            self.claim()
            return
        if path != "/":
            self.send_json({"error": "not found"}, 404)
            return

        origin = request_origin(self)
        self.send_json(
            {
                "rpc_url": f"{origin}/" if origin else "/",
                "claim_url": f"{origin}/claim" if origin else "/claim",
                "player_private_key": PLAYER_PRIVATE_KEY,
                "player_address": PLAYER_ADDRESS,
                "setup_address": SETUP_ADDRESS,
                "vault_address": self.server.vault_address,  # type: ignore[attr-defined]
            }
        )

    def do_POST(self) -> None:  # noqa: N802
        path = urlsplit(self.path).path
        if path == "/claim":
            self.close_connection = True
            self.claim()
            return
        if path not in {"/", "/rpc"}:
            self.send_json({"error": "not found"}, 404)
            return
        if self.headers.get("Transfer-Encoding") is not None:
            self.close_connection = True
            self.send_json(rpc_error(None, -32600, "chunked body unsupported"), 400)
            return

        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            length = 0
        if length <= 0 or length > MAX_BODY:
            self.close_connection = True
            self.send_json(rpc_error(None, -32600, "invalid request size"), 400)
            return

        try:
            payload = json.loads(self.rfile.read(length))
        except json.JSONDecodeError:
            self.send_json(rpc_error(None, -32700, "parse error"), 400)
            return
        self.send_json(proxy(payload))

    def claim(self) -> None:
        try:
            solved = is_solved()
        except (StartupError, ValueError):
            self.send_json({"error": "Anvil unavailable"}, 503)
            return
        if not solved:
            self.send_json({"solved": False, "error": "challenge is not solved"}, 403)
            return
        self.send_json({"solved": True, "flag": self.server.flag})  # type: ignore[attr-defined]

    def log_message(self, fmt: str, *args: object) -> None:
        print(f"[gateway] {self.address_string()} {fmt % args}", flush=True)


def main() -> None:
    flag = os.environ.get("FLAG", "").strip()
    if not flag:
        raise StartupError("FLAG must be provided")

    anvil = subprocess.Popen(
        [
            "anvil",
            "--host",
            "127.0.0.1",
            "--port",
            "8546",
            "--accounts",
            "0",
            "--hardfork",
            "cancun",
            "--load-state",
            "/opt/challenge/state.json",
            "--threads",
            "1",
            "--silent",
        ],
        stdin=subprocess.DEVNULL,
    )

    def stop_anvil() -> None:
        if anvil.poll() is None:
            anvil.terminate()
            try:
                anvil.wait(timeout=5)
            except subprocess.TimeoutExpired:
                anvil.kill()
                anvil.wait()

    atexit.register(stop_anvil)
    wait_for_anvil(anvil)

    server = Server(("0.0.0.0", 8545), Handler)
    server.flag = flag  # type: ignore[attr-defined]
    server.vault_address = read_vault_address()  # type: ignore[attr-defined]

    def terminate(_signum: int, _frame: object) -> None:
        signal.signal(signal.SIGTERM, signal.SIG_IGN)
        signal.signal(signal.SIGINT, signal.SIG_IGN)
        raise SystemExit(0)

    signal.signal(signal.SIGTERM, terminate)
    signal.signal(signal.SIGINT, terminate)

    def watch_anvil() -> None:
        anvil.wait()
        os.kill(os.getpid(), signal.SIGTERM)

    threading.Thread(target=watch_anvil, daemon=True).start()
    print(
        f"[gateway] ready; setup={SETUP_ADDRESS} vault={server.vault_address}",
        flush=True,
    )
    server.serve_forever(poll_interval=0.25)


if __name__ == "__main__":
    try:
        main()
    except StartupError as exc:
        print(f"[gateway] fatal: {exc}", flush=True)
        raise SystemExit(1) from exc
