// SPDX-License-Identifier: MIT
pragma solidity ^0.8.28; // `transient` data location requires solc >= 0.8.28

/// @title FlashVault - the casino's neon "flash-credit" desk.
/// @notice Players open a short-lived flash session to run gas-cheap batched
///         plays within a single transaction.
/// @dev    The session switch lives in TRANSIENT storage (EIP-1153), which is
///         wiped to zero at the end of every transaction -- so the house never
///         bothered to close the session manually.
contract FlashVault {
    address public owner;

    // Transient session flag. Set by openSession(), auto-cleared at end of tx.
    bool transient sessionOpen;

    constructor() payable {
        owner = msg.sender;
    }

    /// @notice Open a flash session for the current transaction.
    function openSession() external {
        sessionOpen = true;
    }

    /// @notice Emergency liquidity pull. Guarded so it is only usable while a
    ///         session is open -- which the house believed meant "only us, in
    ///         the middle of a real flash callback".
    function emergencyDrain() external {
        require(sessionOpen, "no active session");
        (bool ok,) = payable(msg.sender).call{value: address(this).balance}("");
        require(ok, "transfer failed");
    }

    receive() external payable {}
}
