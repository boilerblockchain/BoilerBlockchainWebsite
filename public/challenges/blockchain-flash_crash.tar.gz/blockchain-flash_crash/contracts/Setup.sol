// SPDX-License-Identifier: MIT
pragma solidity ^0.8.28;

import {FlashVault} from "./FlashVault.sol";

/// @title Setup - deploys and seeds the challenge instance.
/// @notice Deploy with 10 ETH. Drain the vault to win.
contract Setup {
    FlashVault public vault;

    constructor() payable {
        require(msg.value == 10 ether, "fund Setup with 10 ETH");
        vault = new FlashVault{value: 10 ether}();
    }

    function isSolved() external view returns (bool) {
        return address(vault).balance == 0;
    }
}
