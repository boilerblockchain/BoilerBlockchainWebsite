const { ethers } = require("ethers");

// Recon helper for Flash Crash. It does NOT solve the challenge -- it connects
// to your deployed instance and prints the state worth looking at.
//
//   RPC_URL        (default http://127.0.0.1:8545)
//   PRIVATE_KEY    your funded key
//   VAULT_ADDRESS  the FlashVault (read it off Setup.vault())

const RPC_URL = process.env.RPC_URL || "http://127.0.0.1:8545";
const PRIVATE_KEY = process.env.PRIVATE_KEY;
const VAULT_ADDRESS = process.env.VAULT_ADDRESS;

const ABI = [
  "function owner() view returns (address)",
  "function openSession()",
  "function emergencyDrain()",
];

async function main() {
  if (!PRIVATE_KEY || !VAULT_ADDRESS) {
    throw new Error("Set PRIVATE_KEY and VAULT_ADDRESS first");
  }

  const provider = new ethers.JsonRpcProvider(RPC_URL);
  const wallet = new ethers.Wallet(PRIVATE_KEY, provider);
  const vault = new ethers.Contract(VAULT_ADDRESS, ABI, wallet);

  console.log("Connected wallet:", wallet.address);
  console.log("Vault address:  ", VAULT_ADDRESS);
  console.log("Vault balance:  ", (await provider.getBalance(VAULT_ADDRESS)).toString());
  console.log("Vault owner:    ", await vault.owner());

  console.log("\nemergencyDrain() needs an open session. openSession() opens one.");
  console.log("Try calling openSession() and then emergencyDrain() as TWO separate");
  console.log("transactions and watch what happens -- then ask how long a value in");
  console.log("*transient* storage actually lives.");
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
