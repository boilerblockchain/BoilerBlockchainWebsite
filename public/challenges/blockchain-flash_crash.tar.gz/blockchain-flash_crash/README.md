# Flash Crash

The casino's neon flash-credit desk lets you open a session, run your plays, and
it auto-closes when your transaction ends — because the session flag lives in
transient storage and "wipes itself every transaction".

Your task is to drain the vault.

## Files

- `contracts/FlashVault.sol` - the flash-credit vault (your target)
- `contracts/Setup.sol` - setup wrapper; deploy with `10 ether`, then use `Setup.vault()`
- `challenge.js` - helper for inspecting a deployed vault

## Hint

Transient storage (EIP-1153) is cleared at the **end of a transaction**, not
between calls inside one. So `openSession()` then `emergencyDrain()` as two
separate transactions won't work — but in a single transaction…

## Run locally

The handout includes the same baked-state Anvil image used by the remote
instance, configured with a dummy local flag:

```bash
docker compose up --build
```

Once it reports ready, open another terminal:

```bash
curl http://127.0.0.1:8545/
```

The response contains the funded player key and contract addresses. Use
`http://127.0.0.1:8545/` as the RPC URL. The local `/claim` response returns
`fake{flag}` after the challenge is solved.
