#!/usr/bin/env bash
set -euo pipefail

rest="${NODE_URL:-http://localnet:8080}"
faucet="${FAUCET_URL:-http://localnet:8081}"
ready_url="${READY_URL:-http://localnet:8070}"
shared="${SHARED_DIR:-/shared}"
funder_amount="${FUNDER_AMOUNT:-100000000000}"

echo "[deploy] waiting for localnet readiness"
until curl -sf "${ready_url}" >/dev/null 2>&1; do sleep 1; done

cd "${HOME:-/root}"
aptos init --profile deployer --network custom \
  --rest-url "${rest}/v1" --faucet-url "${faucet}" --assume-yes >/dev/null
aptos init --profile funder --network custom \
  --rest-url "${rest}/v1" --faucet-url "${faucet}" --assume-yes >/dev/null

deployer_addr=$(aptos config show-profiles --profile deployer | jq -r '.Result.deployer.account')
funder_addr=$(aptos config show-profiles --profile funder | jq -r '.Result.funder.account')
config_file="${HOME:-/root}/.aptos/config.yaml"

extract_raw_key() {
  local profile="$1"
  local aip80_key raw_key
  aip80_key=$(awk -v profile="${profile}" '
    $0 ~ "^  "profile":" { in_profile=1; next }
    /^  [A-Za-z0-9_-]+:/ { in_profile=0 }
    in_profile && /private_key:/ { print $2; exit }
  ' "${config_file}")
  raw_key="${aip80_key#ed25519-priv-}"
  case "${raw_key}" in
    0x[0-9a-fA-F]*) printf '%s\n' "${raw_key}" ;;
    *) echo "[deploy] invalid ${profile} private key format" >&2; exit 1 ;;
  esac
}

funder_key=$(extract_raw_key funder)
package_address="0x${deployer_addr#0x}"

aptos account fund-with-faucet --profile deployer --account "${deployer_addr}" >/dev/null
aptos account fund-with-faucet --profile funder --account "${funder_addr}" \
  --amount "${funder_amount}" >/dev/null

echo "[deploy] publishing trusted_transit at ${package_address}"
aptos move publish --profile deployer --package-dir /work \
  --named-addresses "trusted_transit=${package_address}" \
  --included-artifacts none \
  --assume-yes >/dev/null

source_balance=$(aptos move view --profile deployer \
  --function-id "${package_address}::wdc::balance" \
  --args "address:${package_address}" | jq -r '.Result[0]')
if [[ "${source_balance}" != "1000000000" ]]; then
  echo "[deploy] unexpected source reserve: ${source_balance}" >&2
  exit 1
fi

mkdir -p "${shared}"
printf 'PACKAGE_ADDRESS=%s\nFUNDER_PRIVATE_KEY=%s\n' \
  "${package_address}" "${funder_key}" >"${shared}/deployment.env"
echo "[deploy] snapshot state ready"
