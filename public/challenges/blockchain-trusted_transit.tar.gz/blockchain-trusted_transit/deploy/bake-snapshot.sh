#!/usr/bin/env bash
set -euo pipefail

snapshot_dir="${SNAPSHOT_DIR:-/snapshot}"
localnet_log="${LOCALNET_LOG:-/tmp/trusted-transit-localnet.log}"

rm -rf "${snapshot_dir}"
mkdir -p "${snapshot_dir}"

aptos node run-local-testnet \
  --test-dir "${snapshot_dir}" \
  --assume-yes \
  --bind-to 127.0.0.1 \
  >"${localnet_log}" 2>&1 &
localnet_pid=$!

stop_localnet() {
  kill -TERM "${localnet_pid}" 2>/dev/null || true
  wait "${localnet_pid}" 2>/dev/null || true
}
trap stop_localnet EXIT INT TERM

ready=false
for _ in $(seq 1 180); do
  if curl -fsS http://127.0.0.1:8070 >/dev/null; then ready=true; break; fi
  if ! kill -0 "${localnet_pid}" 2>/dev/null; then break; fi
  sleep 1
done
if [[ "${ready}" != true ]]; then
  sed -n '1,320p' "${localnet_log}" >&2
  echo "[bake] localnet did not become ready" >&2
  exit 1
fi

NODE_URL=http://127.0.0.1:8080 \
FAUCET_URL=http://127.0.0.1:8081 \
READY_URL=http://127.0.0.1:8070 \
SHARED_DIR="${snapshot_dir}" \
  /work/deploy/deploy.sh

stop_localnet
trap - EXIT INT TERM

test -s "${snapshot_dir}/deployment.env"
grep -q '^PACKAGE_ADDRESS=0x' "${snapshot_dir}/deployment.env"
grep -q '^FUNDER_PRIVATE_KEY=0x' "${snapshot_dir}/deployment.env"
find "${snapshot_dir}" -mindepth 1 ! -name deployment.env -print -quit | grep -q .
