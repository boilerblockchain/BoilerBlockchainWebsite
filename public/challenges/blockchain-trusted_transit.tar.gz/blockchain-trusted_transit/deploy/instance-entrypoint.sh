#!/usr/bin/env bash
set -euo pipefail

state_dir="${STATE_DIR:-/data}"
chain_dir="${state_dir}/localnet"
snapshot_dir="${SNAPSHOT_DIR:-/opt/trusted-transit/snapshot}"
baked_chain_dir="${BAKED_CHAIN_DIR:-/snapshot}"

mkdir -p "${state_dir}" "${HOME}" "${chain_dir}"
if [[ ! -e "${chain_dir}/.initialized" ]]; then
  find "${chain_dir}" -mindepth 1 -maxdepth 1 -exec rm -rf -- {} +
  cp -R "${snapshot_dir}/." "${chain_dir}/"
  chmod -R u+rwX "${chain_dir}"
  sed -i "s|${baked_chain_dir}|${chain_dir}|g" "${chain_dir}/0/node.yaml"
  touch "${chain_dir}/.initialized"
fi

. "${chain_dir}/deployment.env"
export PACKAGE_ADDRESS
: "${FLAG:?FLAG must be provided}"
: "${PACKAGE_ADDRESS:?PACKAGE_ADDRESS missing from snapshot}"
: "${FUNDER_PRIVATE_KEY:?FUNDER_PRIVATE_KEY missing from snapshot}"

pids=()
terminate() {
  trap - TERM INT
  for pid in "${pids[@]}"; do kill -TERM "${pid}" 2>/dev/null || true; done
  wait 2>/dev/null || true
}
trap 'terminate; exit 0' TERM INT

aptos node run-local-testnet \
  --test-dir "${chain_dir}" \
  --assume-yes \
  --no-faucet \
  --no-txn-stream \
  --bind-to 127.0.0.1 &
pids+=("$!")

ready=false
for _ in $(seq 1 120); do
  if curl -sf http://127.0.0.1:8070 >/dev/null 2>&1; then ready=true; break; fi
  sleep 1
done
if [[ "${ready}" != true ]]; then
  echo "[instance] localnet failed readiness" >&2
  terminate
  exit 1
fi

package_ready=false
for _ in $(seq 1 60); do
  if aptos move view --url http://127.0.0.1:8080/v1 \
      --function-id "${PACKAGE_ADDRESS}::setup::is_solved" \
      --args address:0x1 >/dev/null 2>&1; then
    package_ready=true
    break
  fi
  sleep 1
done
if [[ "${package_ready}" != true ]]; then
  echo "[instance] baked package unavailable" >&2
  terminate
  exit 1
fi

(cd /opt/gateway && FUNDER_PRIVATE_KEY="${FUNDER_PRIVATE_KEY}" node_modules/.bin/tsx src/index.ts) &
pids+=("$!")

echo "[instance] ready"
wait -n || true
echo "[instance] a core process exited" >&2
terminate
exit 1
