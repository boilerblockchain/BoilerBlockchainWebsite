# Trusted Transit

The Wrapped DCLV bridge has one pending delivery. It is released only to a
relayer certified by a guardian quorum, and none of the guardian keys are
yours.

Get that delivery finalized in your name, and keep the reserve.

## Connect

Register against the per-instance HTTPS endpoint:

```bash
curl -X POST https://INSTANCE/register
```

The response contains a funded Aptos account, the filtered REST URL, and the
deployed package address. Use that account to publish any Move package you
need. When `setup::is_solved(player)` is true, request the flag:

```bash
curl -X POST https://INSTANCE/claim \
  -H 'content-type: application/json' \
  -d '{"address":"0xYOUR_PLAYER_ADDRESS"}'
```

## Goal

The exact win condition is `setup::is_solved`; read it in `sources/setup.move`.

All challenge Move sources are included. The framework revision is pinned in
`Move.toml`; the runtime and solver-compatible Aptos CLI version is `9.4.0`.

## Local instance

```bash
docker compose up --build -d
curl -X POST http://127.0.0.1:8545/register
```

The bridge state is shared by the instance, so registration returns the same
player after the first successful request.
