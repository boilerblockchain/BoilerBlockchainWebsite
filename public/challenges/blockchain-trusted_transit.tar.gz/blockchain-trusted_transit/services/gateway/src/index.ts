import http from "node:http";
import https from "node:https";
import {
  Account,
  Aptos,
  AptosConfig,
  Ed25519PrivateKey,
  Network,
} from "@aptos-labs/ts-sdk";

function required(key: string): string {
  const value = process.env[key];
  if (!value) throw new Error(`Missing required environment variable: ${key}`);
  return value;
}

const NODE_URL = required("NODE_URL");
const PACKAGE_ADDRESS = required("PACKAGE_ADDRESS");
const FLAG = required("FLAG");
const FUNDING = Number(process.env.PLAYER_APT_FUNDING ?? "1000000000");
const PORT = Number(process.env.PORT ?? "3000");
const MAX_BODY_BYTES = 16 * 1024;
const ADDRESS_RE = /^0x[0-9a-fA-F]{1,64}$/;

const aptos = new Aptos(
  new AptosConfig({ network: Network.CUSTOM, fullnode: NODE_URL }),
);
const funder = Account.fromPrivateKey({
  privateKey: new Ed25519PrivateKey(required("FUNDER_PRIVATE_KEY")),
});

function send(res: http.ServerResponse, status: number, body: unknown): void {
  res.writeHead(status, { "content-type": "application/json" });
  res.end(JSON.stringify(body));
}

// Absolute origin of the request, used to hand players a reachable RPC URL.
// Empty when the client sent no Host header, which leaves the URLs relative.
function origin(req: http.IncomingMessage): string {
  const host = req.headers.host;
  if (!host) return "";
  const forwarded = String(req.headers["x-forwarded-proto"] ?? "")
    .split(",", 1)[0]
    .trim();
  return `${forwarded === "https" ? "https" : "http"}://${host}`;
}

async function readBody(req: http.IncomingMessage): Promise<unknown> {
  let data = "";
  for await (const chunk of req) {
    data += chunk;
    if (data.length > MAX_BODY_BYTES) throw new Error("payload too large");
  }
  return data.trim() ? JSON.parse(data) : {};
}

// Everything under /v1 goes straight to the local fullnode, CORS preflights
// included: the node API answers those itself for browser-side tooling.
function proxyFullnode(req: http.IncomingMessage, res: http.ServerResponse): void {
  const base = new URL(NODE_URL);
  const target = new URL(req.url ?? "/v1", `${base.protocol}//${base.host}`);
  const headers: http.OutgoingHttpHeaders = { ...req.headers, host: target.host };
  delete headers.connection;
  delete headers["proxy-connection"];

  const transport = target.protocol === "https:" ? https : http;
  const upstream = transport.request(target, { method: req.method, headers }, (response) => {
    const responseHeaders = { ...response.headers };
    delete responseHeaders.connection;
    delete responseHeaders["transfer-encoding"];
    res.writeHead(response.statusCode ?? 502, responseHeaders);
    response.pipe(res);
  });
  upstream.on("error", () => {
    if (!res.headersSent) send(res, 502, { error: "fullnode unavailable" });
    else res.destroy();
  });
  req.pipe(upstream);
}

async function register(rpcUrl: string) {
  const player = Account.generate();
  const transaction = await aptos.transaction.build.simple({
    sender: funder.accountAddress,
    data: {
      function: "0x1::aptos_account::transfer",
      functionArguments: [player.accountAddress.toString(), FUNDING],
    },
  });
  const pending = await aptos.signAndSubmitTransaction({ signer: funder, transaction });
  await aptos.waitForTransaction({
    transactionHash: pending.hash,
    options: { timeoutSecs: 120, checkSuccess: true },
  });
  return {
    rpc_url: rpcUrl,
    player_address: player.accountAddress.toString(),
    player_private_key: player.privateKey.toHexString(),
    package_address: PACKAGE_ADDRESS,
  };
}

// The SDK only accepts short-form addresses for the reserved 0x0..0xf range, so
// pad claims to the full 32-byte form before handing them to the view call.
function normalizeAddress(address: string): string {
  return `0x${address.slice(2).padStart(64, "0")}`;
}

async function isSolved(player: string): Promise<boolean> {
  const result = await aptos.view({
    payload: {
      function: `${PACKAGE_ADDRESS}::setup::is_solved`,
      functionArguments: [normalizeAddress(player)],
    },
  });
  return result[0] === true;
}

// The bridge state is shared by the instance, so there is exactly one player.
let registration: ReturnType<typeof register> | undefined;

const server = http.createServer(async (req, res) => {
  try {
    const url = req.url ?? "/";

    if (req.method === "GET" && url === "/health") {
      send(res, 200, { status: "ok" });
    } else if (req.method === "GET" && url === "/") {
      send(res, 200, {
        name: "Trusted Transit",
        rpc_url: `${origin(req)}/v1`,
        register_url: `${origin(req)}/register`,
        claim_url: `${origin(req)}/claim`,
      });
    } else if (url === "/v1" || url.startsWith("/v1/") || url.startsWith("/v1?")) {
      proxyFullnode(req, res);
    } else if (req.method === "POST" && url === "/register") {
      if (!registration) {
        registration = register(`${origin(req)}/v1`).catch((error) => {
          registration = undefined;
          throw error;
        });
      }
      send(res, 200, await registration);
    } else if (req.method === "POST" && url === "/claim") {
      let address: unknown;
      try {
        address = ((await readBody(req)) as { address?: unknown } | null)?.address;
      } catch {
        send(res, 400, { error: "invalid JSON body" });
        return;
      }
      if (typeof address !== "string" || !ADDRESS_RE.test(address)) {
        send(res, 400, { error: "missing or invalid 'address'" });
      } else if (await isSolved(address)) {
        send(res, 200, { solved: true, flag: FLAG });
      } else {
        send(res, 200, { solved: false });
      }
    } else {
      send(res, 404, { error: "not found" });
    }
  } catch (error) {
    console.error("gateway request failed", error);
    if (!res.headersSent) send(res, 500, { error: "internal error" });
  }
});

server.listen(PORT, () => console.log(`gateway listening on :${PORT}`));
