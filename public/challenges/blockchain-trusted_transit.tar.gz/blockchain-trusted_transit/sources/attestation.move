module trusted_transit::attestation {
    use std::bcs;
    use aptos_std::ed25519;

    const EUNKNOWN_GUARDIAN: u64 = 1;
    const EDUPLICATE_GUARDIAN: u64 = 2;
    const EINVALID_SIGNATURE: u64 = 3;
    const EQUORUM_NOT_MET: u64 = 4;
    const EFOREIGN_GUARDIAN: u64 = 5;
    const EGUARDIAN_INDEX: u64 = 6;

    const QUORUM: u64 = 3;
    const GUARDIAN_0: address = @0x101;
    const GUARDIAN_1: address = @0x202;
    const GUARDIAN_2: address = @0x303;
    const GUARDIAN_3: address = @0x404;

    const PK0: vector<u8> = x"60dce867175d04284dfcbec8d4f74217ffa4d9dd83ae4fc23871e7ea0d7496be";
    const PK1: vector<u8> = x"9b29fec65a932e77c4dc3ddb46404a97a7f41b578a99ce47cb50a014f8cf30a3";
    const PK2: vector<u8> = x"9b487a0415f2162047f61205f21855179d8ede9edf79c19745d3aba95d392e52";
    const PK3: vector<u8> = x"19b358f02a0200046f9ddac3f0b81251598c1db3a0cd4ac59e7d705e82e3169b";

    public struct Certification {
        candidate: address,
        message_id: u64,
        votes: vector<address>
    }

    #[view]
    public fun guardian(index: u64): address {
        if (index == 0) GUARDIAN_0
        else if (index == 1) GUARDIAN_1
        else if (index == 2) GUARDIAN_2
        else {
            assert!(index == 3, EGUARDIAN_INDEX);
            GUARDIAN_3
        }
    }

    public fun new(candidate: address, message_id: u64): Certification {
        Certification { candidate, message_id, votes: vector[] }
    }

    public fun record_vote(
        cert: &mut Certification, public_key_bytes: vector<u8>, signature_bytes: vector<u8>
    ) {
        let guardian = guardian_for_key(&public_key_bytes);
        assert!(!cert.votes.contains(&guardian), EDUPLICATE_GUARDIAN);

        let public_key = ed25519::new_unvalidated_public_key_from_bytes(public_key_bytes);
        let signature = ed25519::new_signature_from_bytes(signature_bytes);
        assert!(
            ed25519::signature_verify_strict(
                &signature,
                &public_key,
                signing_message(cert.candidate, cert.message_id)
            ),
            EINVALID_SIGNATURE
        );
        cert.votes.push_back(guardian);
    }

    public fun assert_quorum(cert: &Certification) {
        let len = cert.votes.length();
        let i = 0;
        while (i < len) {
            let vote = cert.votes[i];
            assert!(is_guardian(vote), EFOREIGN_GUARDIAN);
            let j = i + 1;
            while (j < len) {
                assert!(vote != cert.votes[j], EDUPLICATE_GUARDIAN);
                j += 1;
            };
            i += 1;
        };
        assert!(len >= QUORUM, EQUORUM_NOT_MET);
    }

    public fun destroy(cert: Certification) {
        let Certification { candidate: _, message_id: _, votes: _ } = cert;
    }

    fun guardian_for_key(public_key: &vector<u8>): address {
        if (*public_key == PK0) GUARDIAN_0
        else if (*public_key == PK1) GUARDIAN_1
        else if (*public_key == PK2) GUARDIAN_2
        else {
            assert!(*public_key == PK3, EUNKNOWN_GUARDIAN);
            GUARDIAN_3
        }
    }

    fun is_guardian(candidate: address): bool {
        candidate == GUARDIAN_0
            || candidate == GUARDIAN_1
            || candidate == GUARDIAN_2
            || candidate == GUARDIAN_3
    }

    fun signing_message(candidate: address, message_id: u64): vector<u8> {
        let message = b"TRUSTED_TRANSIT_RELAY_V1";
        message.append(bcs::to_bytes(&@trusted_transit));
        message.append(bcs::to_bytes(&candidate));
        message.append(bcs::to_bytes(&message_id));
        message
    }
}
