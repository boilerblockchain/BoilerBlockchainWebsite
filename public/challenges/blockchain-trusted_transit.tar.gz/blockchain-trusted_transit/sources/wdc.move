module trusted_transit::wdc {
    use std::option;
    use std::string::utf8;
    use aptos_framework::fungible_asset::{
        Self,
        FungibleAsset,
        Metadata,
        MintRef,
        TransferRef
    };
    use aptos_framework::object::{Self, Object};
    use aptos_framework::primary_fungible_store;

    const RESERVE_AMOUNT: u64 = 1_000_000_000;
    const DECIMALS: u8 = 6;

    struct Refs has key {
        mint_ref: MintRef,
        transfer_ref: TransferRef,
        metadata: Object<Metadata>
    }

    #[view]
    public fun metadata(): Object<Metadata> {
        Refs[@trusted_transit].metadata
    }

    #[view]
    public fun balance(owner: address): u64 {
        primary_fungible_store::balance(owner, metadata())
    }

    #[view]
    public fun reserve_amount(): u64 {
        RESERVE_AMOUNT
    }

    package fun mint_reserve(): FungibleAsset {
        Refs[@trusted_transit].mint_ref.mint(RESERVE_AMOUNT)
    }

    package fun withdraw_source(amount: u64): FungibleAsset {
        primary_fungible_store::withdraw_with_ref(
            &Refs[@trusted_transit].transfer_ref, @trusted_transit, amount
        )
    }

    fun init_module(publisher: &signer) {
        let constructor_ref = &object::create_named_object(publisher, b"WDC");
        primary_fungible_store::create_primary_store_enabled_fungible_asset(
            constructor_ref,
            option::none(),
            utf8(b"Wrapped DCLV"),
            utf8(b"WDC"),
            DECIMALS,
            utf8(b""),
            utf8(b"")
        );
        let mint_ref = fungible_asset::generate_mint_ref(constructor_ref);
        let transfer_ref = fungible_asset::generate_transfer_ref(constructor_ref);
        let metadata = constructor_ref.object_from_constructor_ref<Metadata>();
        move_to(
            publisher,
            Refs { mint_ref, transfer_ref, metadata }
        );
    }
}
