module trusted_transit::setup {
    use trusted_transit::bridge;
    use trusted_transit::wdc;

    #[view]
    public fun is_solved(player: address): bool {
        let amount = bridge::pending_amount();
        bridge::last_relayer() == std::option::some(player)
            && bridge::destination_balance() == amount
            && wdc::balance(player) >= amount
    }
}
