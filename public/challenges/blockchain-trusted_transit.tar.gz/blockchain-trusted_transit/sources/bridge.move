module trusted_transit::bridge {
    use std::option::{Self, Option};
    use aptos_framework::fungible_asset::{FungibleAsset, Metadata};
    use aptos_framework::object::Object;
    use aptos_framework::primary_fungible_store;
    use trusted_transit::attestation::{Self, Certification};
    use trusted_transit::wdc;

    const EATTESTATION_CONTEXT_CHANGED: u64 = 1;
    const EPERMIT_CANDIDATE: u64 = 2;
    const EPERMIT_MESSAGE: u64 = 3;
    const EPERMIT_AMOUNT: u64 = 4;
    const EALREADY_FINALIZED: u64 = 5;
    const EWRONG_INITIAL_ASSET: u64 = 6;
    const EWRONG_INITIAL_AMOUNT: u64 = 7;
    const EWRONG_FINAL_AMOUNT: u64 = 8;
    const EDESTINATION_OCCUPIED: u64 = 9;

    const MESSAGE_ID: u64 = 1;
    const DESTINATION: address = @0xD357;

    struct BridgeState has key {
        message_id: u64,
        amount: u64,
        destination: address,
        delivered_metadata: Option<Object<Metadata>>,
        finalized: bool,
        last_relayer: Option<address>
    }

    struct RelayPermit {
        candidate: address,
        message_id: u64,
        amount: u64
    }

    #[view]
    public fun pending_amount(): u64 {
        BridgeState[@trusted_transit].amount
    }

    #[view]
    public fun destination_metadata(): Option<address> {
        let delivered = &BridgeState[@trusted_transit].delivered_metadata;
        if (delivered.is_some()) {
            option::some(delivered.borrow().object_address())
        } else {
            option::none()
        }
    }

    #[view]
    public fun destination_balance(): u64 {
        let state = &BridgeState[@trusted_transit];
        if (state.delivered_metadata.is_some()) {
            primary_fungible_store::balance(
                state.destination, *state.delivered_metadata.borrow()
            )
        } else { 0 }
    }

    #[view]
    public fun is_finalized(): bool {
        BridgeState[@trusted_transit].finalized
    }

    #[view]
    public fun last_relayer(): Option<address> {
        BridgeState[@trusted_transit].last_relayer
    }

    public fun certify_relayer(
        player: &signer, verifier: |&mut Certification|
    ): RelayPermit {
        let candidate = player.address_of();
        let message_id = BridgeState[@trusted_transit].message_id;
        let amount = BridgeState[@trusted_transit].amount;
        let cert = attestation::new(candidate, message_id);
        verifier(&mut cert);
        assert!(
            cert.candidate == candidate && cert.message_id == message_id,
            EATTESTATION_CONTEXT_CHANGED
        );
        attestation::assert_quorum(&cert);
        attestation::destroy(cert);
        RelayPermit { candidate, message_id, amount }
    }

    public fun relay(
        player: &signer, permit: RelayPermit, delivery_hook: |&mut FungibleAsset|
    ) {
        let RelayPermit { candidate, message_id, amount } = permit;
        let player_address = player.address_of();
        let state = &BridgeState[@trusted_transit];
        assert!(candidate == player_address, EPERMIT_CANDIDATE);
        assert!(message_id == state.message_id, EPERMIT_MESSAGE);
        assert!(amount == state.amount, EPERMIT_AMOUNT);
        assert!(!state.finalized, EALREADY_FINALIZED);
        assert!(state.delivered_metadata.is_none(), EDESTINATION_OCCUPIED);
        let destination = state.destination;

        let asset = wdc::withdraw_source(amount);
        assert!(
            asset.asset_metadata().object_address() == wdc::metadata().object_address(),
            EWRONG_INITIAL_ASSET
        );
        assert!(asset.amount() == amount, EWRONG_INITIAL_AMOUNT);

        delivery_hook(&mut asset);
        assert!(asset.amount() == amount, EWRONG_FINAL_AMOUNT);

        let delivered_metadata = asset.asset_metadata();
        primary_fungible_store::deposit(destination, asset);

        let state = &mut BridgeState[@trusted_transit];
        state.delivered_metadata.fill(delivered_metadata);
        state.finalized = true;
        state.last_relayer.fill(player_address);
    }

    fun init_module(publisher: &signer) {
        primary_fungible_store::deposit(@trusted_transit, wdc::mint_reserve());
        move_to(
            publisher,
            BridgeState {
                message_id: MESSAGE_ID,
                amount: wdc::reserve_amount(),
                destination: DESTINATION,
                delivered_metadata: option::none(),
                finalized: false,
                last_relayer: option::none()
            }
        );
    }
}
