const { ethers } = require("ethers");

// Recon helper for Multisig Mayhem. It does NOT solve the challenge -- it
// connects to your deployed instance and prints the state worth looking at.
//
//   RPC_URL        (default http://127.0.0.1:8545)
//   PRIVATE_KEY    funded key returned by GET /
//   VAULT_ADDRESS  MultiSigWallet address returned by GET / as wallet_address

const RPC_URL = process.env.RPC_URL || "http://127.0.0.1:8545";
const PRIVATE_KEY = process.env.PRIVATE_KEY;
const VAULT_ADDRESS = process.env.VAULT_ADDRESS || process.env.WALLET_ADDRESS;

const ABI = [
  "function owners(uint256) view returns (address)",
  "function advertisedRequiredSignatures() view returns (uint256)",
  "function executionThreshold() view returns (uint256)",
  "function getTransactionHash(address destination,uint256 value,bytes data) view returns (bytes32)",
  "function submitTransaction(address destination,uint256 value,bytes data,uint8[] v,bytes32[] r,bytes32[] s)",
  "function drained() view returns (bool)",
  "function isOwner(address) view returns (bool)",
];

async function main() {
  if (!PRIVATE_KEY || !VAULT_ADDRESS) {
    throw new Error("Set PRIVATE_KEY and VAULT_ADDRESS (or WALLET_ADDRESS) first");
  }

  const provider = new ethers.JsonRpcProvider(RPC_URL);
  const wallet = new ethers.Wallet(PRIVATE_KEY, provider);
  const vault = new ethers.Contract(VAULT_ADDRESS, ABI, wallet);

  console.log("Connected wallet:", wallet.address);
  console.log("Vault address:  ", VAULT_ADDRESS);
  console.log(
    "Vault balance:  ",
    (await provider.getBalance(VAULT_ADDRESS)).toString(),
  );
  console.log(
    "Advertised threshold:",
    (await vault.advertisedRequiredSignatures()).toString(),
  );
  console.log(
    "executionThreshold():",
    (await vault.executionThreshold()).toString(),
  );

  for (let i = 0; i < 3; i++) {
    try {
      console.log(`Owner ${i}:`, await vault.owners(i));
    } catch (_) {
      break;
    }
  }

  console.log(
    "\nInspect submitTransaction carefully. ecrecover recovers a signer --",
  );
  console.log("does the contract ever check that the signer is an owner?");
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
