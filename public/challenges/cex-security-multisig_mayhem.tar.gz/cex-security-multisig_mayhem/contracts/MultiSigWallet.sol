// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/// @title Sin City Jackpot Vault - intentionally vulnerable training contract
/// @notice Do not use this code in production.
contract MultiSigWallet {
    address[] public owners;
    mapping(address => bool) public isOwner;
    mapping(bytes32 => uint256) public transactionNonce;

    uint256 public advertisedRequiredSignatures;
    bool public drained;

    event TransactionExecuted(address indexed destination, uint256 value, bytes data, address indexed signer);

    constructor(address[] memory _owners) payable {
        require(_owners.length >= 3, "need three owners");
        for (uint256 i = 0; i < _owners.length; i++) {
            require(_owners[i] != address(0), "zero owner");
            require(!isOwner[_owners[i]], "duplicate owner");
            owners.push(_owners[i]);
            isOwner[_owners[i]] = true;
        }
        advertisedRequiredSignatures = 3;
    }

    receive() external payable {}

    function executionThreshold() public pure returns (uint256) {
        return 1;
    }


    function getTransactionHash(address destination, uint256 value, bytes memory data) public view returns (bytes32) {
        bytes32 key = keccak256(abi.encode(destination, value, data));
        uint256 nonce = transactionNonce[key];
        return keccak256(abi.encodePacked(destination, value, data, nonce, address(this)));
    }

    function submitTransaction(
        address payable destination,
        uint256 value,
        bytes memory data,
        uint8[] memory v,
        bytes32[] memory r,
        bytes32[] memory s
    ) public {
        bytes32 key = keccak256(abi.encode(destination, value, data));
        uint256 nonce = transactionNonce[key];
        transactionNonce[key] = nonce + 1;

        uint256 required = executionThreshold();
        require(v.length >= required && r.length >= required && s.length >= required, "not enough signatures");

        bytes32 txHash = keccak256(abi.encodePacked(destination, value, data, nonce, address(this)));
        address lastSigner = address(0);
        address recoveredSigner = address(0);

        for (uint256 i = 0; i < required; i++) {
            address signer = ecrecover(txHash, v[i], r[i], s[i]);
            require(signer != address(0), "bad signature");
            require(signer > lastSigner, "invalid signer order");
            lastSigner = signer;
            recoveredSigner = signer;
        }

        (bool success, ) = destination.call{value: value}(data);
        require(success, "transaction execution failed");
        if (address(this).balance == 0) {
            drained = true;
        }
        emit TransactionExecuted(destination, value, data, recoveredSigner);
    }
}
