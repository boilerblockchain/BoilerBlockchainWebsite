// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {MultiSigWallet} from "./MultiSigWallet.sol";

/// @title Setup - deploys and seeds the Multisig Mayhem instance.
contract Setup {
    MultiSigWallet public immutable wallet;

    constructor() payable {
        require(msg.value == 10 ether, "fund Setup with 10 ETH");

        address[] memory owners = new address[](3);
        owners[0] = address(0xA11CE);
        owners[1] = address(0xB0B);
        owners[2] = address(0xCAFE);

        wallet = new MultiSigWallet{value: msg.value}(owners);
    }

    function isSolved() external view returns (bool) {
        return address(wallet).balance == 0 && wallet.drained();
    }
}
