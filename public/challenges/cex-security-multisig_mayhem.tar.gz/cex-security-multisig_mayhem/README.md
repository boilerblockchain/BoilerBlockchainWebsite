# Multisig Mayhem

The Sin City Jackpot Vault claims to be a three-owner multi-signature wallet.

Your task is to drain the vault.

## Files

- `contracts/MultiSigWallet.sol` - vulnerable vault
- `contracts/Setup.sol` - setup wrapper; seeds three owners and 10 ETH
- `challenge.js` - helper for inspecting a deployed vault

## Hint

`ecrecover` only tells you which address produced a signature. The contract still
has to check whether that address is authorized.

## Run locally

The handout includes the same baked-state Anvil image used by the remote
instance, configured with a dummy local flag:

```bash
docker compose up --build
```

Once it reports ready, open another terminal:

```bash
curl http://127.0.0.1:8545/
```

The response contains the funded player key and contract addresses. Use
`http://127.0.0.1:8545/` as the RPC URL. The local `/claim` response returns
`fake{flag}` after the challenge is solved. Set `RPC_PORT` if port 8545 is
already in use.
